

Please install node_modules and run 'npm run serv' to run locally.

#Libraries used,
React
Redux
Styled Components



